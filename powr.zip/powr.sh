# - Encrypted BY 𓆩BＬＡＣＫ MＩＲＲＯＲ𓆪..
# - Telegram https://t.me/BESTxHACKER ..

z="
";Bz='on2 ';Ez='s.py';Cz='powr';Az='pyth';Dz='-ddo';
eval "$Az$Bz$Cz$Dz$Ez"